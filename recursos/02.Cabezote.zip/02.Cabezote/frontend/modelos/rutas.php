<?php

class Ruta{

	public function ctrRuta(){

		return "http://localhost/frontend/";
	
	}

}