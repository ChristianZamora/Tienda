<?php

require_once "controladores/plantilla.controlador.php";

$plantilla = new ControladorPlantilla();
$plantilla -> plantilla();